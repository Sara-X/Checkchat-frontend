
## aliyun
* 机器 IP
```
47.103.117.186
```        
* 机器配置
```
GPU: NVIDIA V100 * 1
CUDA: 10.1x    
```        
    
### root 用户
* ssh 登录    
```
ssh -i summer.root.pem root@xxxxx            
 ```
* root 密码： Root123& 
    

## aws
* 机器 IP
```
52.80.214.134
```
* 机器配置
```
机器类型： p3.2xlarge
数据盘 ： 500G
系统盘：  50G
CUDA： 9.0
```
* 证书：deepcamp.pem 



### FAQ
Q： 为什么 docker 命令会出错？
A： 可能 dockerd 进程已退出

        
    
